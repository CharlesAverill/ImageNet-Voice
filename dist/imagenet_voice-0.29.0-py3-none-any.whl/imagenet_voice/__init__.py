from imagenet_voice import load
from imagenet_voice import load_n
from imagenet_voice import load_classes
